#!/usr/bin/env python3

from ludo.cli import CLIGame


CLIGame().start()
